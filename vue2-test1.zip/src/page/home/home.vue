<template>
  <div class="page home">
    <div class="page-header">
      <head-top header-title="Home" go-back="0"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll">
        <h1>{{msg}} home</h1>
        <section>
          <div>aaaaaaa</div>
          <div>
            <div>bbbb</div>
            <div>cccc</div>
          </div>
        </section>
      </div>
    </div>
    <div class="page-footer">
      <foot-guide></foot-guide>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
import footGuide from '@/components/footer'
export default {
  name: 'home',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop,
    footGuide
  }
}
</script>

<style lang="scss" scoped>
  @import 'src/css/mixin';
  .home {
    background-color: #f2f6f2;
    text-align: center;
    line-height: 100px;
  }
</style>
