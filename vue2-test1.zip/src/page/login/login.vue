<template>
  <div class="page login">
    <div class="page-header">
      <head-top header-title="Login"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} login</h1>
      </div>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'login',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.login {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
}
</style>
