<template>
  <div class="page channel">
    <div class="page-header">
      <head-top header-title="Channel" go-back="0"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll">
        <h1>{{msg}} channel</h1>
      </div>
    </div>
    <div class="page-footer">
      <foot-guide></foot-guide>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
import footGuide from '@/components/footer'
export default {
  name: 'home',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop,
    footGuide
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.channel {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
}
</style>
