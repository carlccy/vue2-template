<template>
  <div class="page confirmOrder">
    <div class="page-header">
      <head-top header-title="ConfirmOrder"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} confirmOrder</h1>
        <section @click="gotoAddress({path: 'confirmOrder/chooseAddress'})">选择地址</section>
        <section @click="gotoAddress({path: 'confirmOrder/coupon'})">优惠券</section>
        <section @click="gotoAddress({path: 'confirmOrder/invoice'})">发票</section>
        <section>asdfasdfasd1</section>
        <section>asdfasdfasd2</section>
        <section>asdfasdfasd3</section>
        <section>asdfasdfasd4</section>
        <section>asdfasdfasd5</section>
        <section>asdfasdfasd6</section>
        <section>asdfasdfasd7</section>
        <section>asdfasdfasd8</section>
        <section>asdfasdfasd9</section>
      </div>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'confirmOrder',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  },
  methods: {
    gotoAddress (path) {
      this.$router.push(path)
    }
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.confirmOrder {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
  overflow: hidden;
}
</style>
