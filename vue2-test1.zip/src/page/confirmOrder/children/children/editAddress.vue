<template>
  <div class="page editAddress">
    <div class="page-header">
      <head-top header-title="EditAddress"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} editAddress</h1>
      </div>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'editAddress',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.editAddress {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
  @include sub
}
</style>
