<template>
  <div class="page addAddress">
    <div class="page-header">
      <head-top header-title="addAddress"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} AddAddress</h1>
      </div>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'addAddress',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.addAddress {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
  @include sub
}
</style>
