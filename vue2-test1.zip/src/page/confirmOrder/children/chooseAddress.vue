<template>
  <div class="page chooseAddress">
    <div class="page-header">
      <head-top header-title="ChooseAddress"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} chooseAddress</h1>
        <router-link to="/confirmOrder/chooseAddress/addAddress">
          <span>新增收货地址</span>
        </router-link>
        <router-link to="/confirmOrder/chooseAddress/editAddress">
          <span>编辑收货地址</span>
        </router-link>
      </div>
    </div>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'chooseAddress',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.chooseAddress {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
  @include sub
}
</style>
