<template>
  <div class="page coupon">
    <div class="page-header">
      <head-top header-title="Coupon"></head-top>
    </div>
    <div class="page-content">
      <div class="page-scroll-nofooter">
        <h1>{{msg}} coupon</h1>
      </div>
    </div>
  </div>
</template>

<script>
import headTop from '@/components/head'
export default {
  name: 'coupon',
  data () {
    return {
      msg: 'welcome to'
    }
  },
  components: {
    headTop
  }
}
</script>

<style lang="scss" scoped>
@import 'src/css/mixin';
.coupon {
  background-color: #f2f6f2;
  text-align: center;
  line-height: 100px;
}
</style>
