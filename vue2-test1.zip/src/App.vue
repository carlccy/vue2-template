<template>
  <transition name="router-fade" mode="out-in">
    <router-view/>
  </transition>
</template>

<script>
  export default {
    name: 'app'
  }
</script>

<style lang="scss">
  @import 'src/css/common';
  
	.router-fade-enter-active, .router-fade-leave-active {
	  	transition: opacity .3s;
	}
	.router-fade-enter, .router-fade-leave-active {
	  	opacity: 0;
	}
</style>
